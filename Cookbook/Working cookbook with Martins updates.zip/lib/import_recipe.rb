require 'nokogiri'
require 'open-uri'

class ImportRecipe
  def initialize(keyword)
    @recipes = []
    @titles = []
    @descr = []
    @keyowrd = keyword
    @doc = Nokogiri::HTML(open("https://www.epicurious.com/search/#{@keyword}").read)

  end

  def list_online_recipes
    @doc.xpath("//header//strong").each_with_index do |recipe, i|
      @recipes << "#{recipe.text}"
      break if i >= 9
    end

    @doc.xpath("//h4//a").each_with_index do |title, i|
      @titles << "#{title.text}"
      break if i >= 9
    end
    @doc.xpath("//header//p").each_with_index do |desc, i|
      @descr << "#{desc.text}"
      break if i >= 9
    end
    # @online_recipes = Hash[@titles.zip @descr]
    # return @online_recipes.to_a

    @online_recipes = @recipes.zip(@titles, @descr)
    return @online_recipes

  end
end







