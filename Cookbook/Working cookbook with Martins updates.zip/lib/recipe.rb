class Recipe
  attr_reader :name, :description, :task, :category
  def initialize(category = "Recipe", name, description)
    @name = name
    @description = description
    @category = category
    @task = false
  end

  def done?
    @task ?  "[x]" : "[ ]"
  end

  def mark_as_done!
    @task = true
  end
end
