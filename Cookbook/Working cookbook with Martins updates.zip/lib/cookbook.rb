require 'csv'

class Cookbook
  def initialize(csv_path)
    @csv_path = csv_path
    @recipes = []
    load_csv
  end

  def load_csv
    CSV.foreach(@csv_path) do |line|
      @recipes << Recipe.new(line[0], line[1])
    end
  end

  def add_recipe(recipe)
    @recipes << recipe
    CSV.open(@csv_path, 'wb') do |csv|
      @recipes.each { |item| csv << [item.name, item.description] }
    end
  end

  def remove_recipe(index)
    @recipes.delete_at(index - 1)
    CSV.open(@csv_path, 'wb') do |csv|
      @recipes.each do |item|
        csv << [item.name, item.description]
      end
    end
  end

  def remove_all
    @recipes = []
  end

  def all
    @recipes
  end

  def find(index)
    @recipes[index]
  end
end
