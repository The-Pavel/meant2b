require_relative 'recipe_view'
require_relative 'recipe'

class Controller
  def initialize(cookbook)
    @cookbook = cookbook
    @view = RecipeView.new
  end

  def list
    recipes = @cookbook.all
    @view.display(recipes)
  end

  def create
    recipe = @view.ask_for_name
    description = @view.ask_for_description
    @cookbook.add_recipe(Recipe.new(category, recipe, description))
  end

  def destroy
    i = @view.ask_for_index
    @cookbook.remove_recipe(i+1)
  end

  def create_from_online
    search = ImportRecipe.new(@view.ask_for_keyword)
    temp_array = @view.display_online_recipes(search)
    @cookbook.add_recipe(Recipe.new(temp_array[0], temp_array[1], temp_array[2]))
  end

  def mark_as_done
    list
    index = @view.ask_for_index
    task = @cookbook.find(index)
    if task != nil
      task.mark_as_done!
    else
      puts "Try again"
    end

  end

  def destroy_all
    @cookbook.remove_all
  end

end
