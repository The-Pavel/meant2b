require_relative 'import_recipe'

class RecipeView
  def display(recipes)
    puts "======== Your Recipes ========"
    recipes.each_with_index do |recipe, index|
      puts "#{recipe.done?} recipe #{index + 1}: #{recipe.category} #{recipe.name} #{recipe.description}"
    end
  end

  def ask_for_name
    puts "What is the name of your recipe?"
    gets.chomp
  end

  def ask_for_description
    puts "Write description, ingredients, and procedures"
    gets.chomp
  end

  def ask_for_index
    puts "Which recipe number will you choose?"
    gets.chomp.to_i-1
  end

  def ask_for_keyword
    puts "What ingredient would you like a recipe for?"
    gets.chomp
  end

  def display_online_recipes(search)
    puts "The following recipes were found"
    new_array = search.list_online_recipes
    new_array.each_with_index do |recipes, i|
      puts "#{i+1} - #{recipes[0]} >>>> #{recipes[1]} >>>> (#{recipes[2]})"
    end
    return new_array[ask_for_index]
  end
end
